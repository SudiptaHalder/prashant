export const name = 'searchBox' as const

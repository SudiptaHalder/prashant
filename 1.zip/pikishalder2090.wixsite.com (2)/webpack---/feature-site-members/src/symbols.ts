export const SiteMembersSymbol = Symbol('SiteMembers')
export const SiteMembersApiSymbol = Symbol('SiteMembersApi')

export const name = 'siteMembers' as const

export const DialogComponentId = 'SM_ROOT_COMP'

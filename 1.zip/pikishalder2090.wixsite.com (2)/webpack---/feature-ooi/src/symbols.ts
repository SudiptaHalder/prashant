export const name = 'ooi' as const
export const ReactLoaderForOOISymbol = Symbol.for('ReactLoaderForOOISymbol')
export const OOISsrManagerSymbol = Symbol.for('OOISsrManager')
export const ModuleFederationSharedScopeSymbol = Symbol.for('ModuleFederationSharedScope')
export const OOIPageComponentsLoaderSymbol = Symbol.for('OOIPageComponentsLoader')

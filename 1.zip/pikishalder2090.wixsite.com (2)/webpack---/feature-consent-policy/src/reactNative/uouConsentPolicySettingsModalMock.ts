import type { IUOUConsentPolicySettingsModal } from '../types'

export const UouConsentPolicySettingsModalMock: IUOUConsentPolicySettingsModal = {
	open() {
		return () => {}
	},
}

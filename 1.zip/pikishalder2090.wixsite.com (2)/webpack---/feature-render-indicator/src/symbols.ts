export const name = 'renderIndicator' as const
export const RenderIndicatorSymbol = Symbol('renderIndicator')

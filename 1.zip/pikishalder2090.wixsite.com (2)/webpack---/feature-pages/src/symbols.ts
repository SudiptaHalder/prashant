export const PageProviderSymbol = Symbol('PageProvider')
export const LogicalReflectorSymbol = Symbol('LogicalReflector')
export const PageStructureJsonSymbol = Symbol('PageStructure')
export const PagePropsJsonSymbol = Symbol('PageProps')
export const PageInitializerSymbol = Symbol('PageInitializer')

export const name = 'pages' as const

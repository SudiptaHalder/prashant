import GroupSdk from '@wix/thunderbolt-elements/src/components/Group/corvid/Group.corvid';


const Group = {
  sdk: GroupSdk
};


export const components = {
  ['Group']: Group
};


export const ACTIVE_POPUP_OBSERVERS_TYPES = ['DropDownMenu']

import ColumnSdk from '@wix/thunderbolt-elements/src/components/Column/corvid/Column.corvid';


const Column = {
  sdk: ColumnSdk
};


export const components = {
  ['Column']: Column
};


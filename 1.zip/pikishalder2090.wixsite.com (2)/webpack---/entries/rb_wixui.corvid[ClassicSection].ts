import ClassicSectionSdk from '@wix/thunderbolt-elements/src/components/ClassicSection/corvid/ClassicSection.corvid';


const ClassicSection = {
  sdk: ClassicSectionSdk
};


export const components = {
  ['ClassicSection']: ClassicSection
};


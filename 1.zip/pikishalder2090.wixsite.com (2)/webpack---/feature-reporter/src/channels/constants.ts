export const PROMOTE_BI_ENDPOINT = 'pa'
export const PV_EVENT = {
	SRC: 76,
	EVID: 1109,
}
export const PURCHASE_EVENT = {
	SRC: 76,
	EVID: 1107,
}

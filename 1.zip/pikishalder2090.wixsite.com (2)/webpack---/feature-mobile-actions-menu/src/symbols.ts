export const name = 'mobileActionsMenu'
export const MOBILE_ACTIONS_MENU_ID = 'MOBILE_ACTIONS_MENU'
export const MOBILE_ACTIONS_MENU_COMP_TYPE = 'MobileActionsMenu'

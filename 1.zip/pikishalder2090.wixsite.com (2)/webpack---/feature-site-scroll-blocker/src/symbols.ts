export const SiteScrollBlockerSymbol = Symbol('SiteScrollBlocker')

export const name = 'siteScrollBlocker' as const

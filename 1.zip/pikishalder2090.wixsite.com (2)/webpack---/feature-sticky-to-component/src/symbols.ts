export const name = 'stickyToComponent' as const
export const StickyToComponentSymbol = Symbol('StickyToComponent')
export const ShouldObserveHeaderHandlerSymbol = Symbol('ShouldObserveHeaderHandler')

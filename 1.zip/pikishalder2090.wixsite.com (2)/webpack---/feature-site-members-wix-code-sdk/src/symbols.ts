export const name = 'siteMembersWixCodeSdk' as const
export const namespace = 'user' as const
export const memberNamespace = 'members' as const

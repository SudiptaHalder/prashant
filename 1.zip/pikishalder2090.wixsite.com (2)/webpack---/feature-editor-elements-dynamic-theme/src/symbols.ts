export const name = 'editorElementsDynamicTheme' as const
